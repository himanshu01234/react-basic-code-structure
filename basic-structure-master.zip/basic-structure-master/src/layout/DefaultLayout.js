import React, { Fragment} from 'react';

function  DefaultLayout ({children}){
        return (
            <Fragment>
                {children}
            </Fragment>
        );
}

export default DefaultLayout;