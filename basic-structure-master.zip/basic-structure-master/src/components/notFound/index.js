import React, {Fragment}  from 'react';

function NotFound (props){
    return (
        <Fragment>
            <h1>404 Not Found</h1>
        </Fragment>
    );
}

export default NotFound;