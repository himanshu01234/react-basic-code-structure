import React, {Component} from 'react';

class SignIn extends Component {
    render() {
        return (
            <div>
            <h1>SignIn</h1>
            </div>
        );
    }
}

export default SignIn;