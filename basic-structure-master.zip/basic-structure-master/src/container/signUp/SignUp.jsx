import React, {Component} from 'react';

class SignUp extends Component {
    render() {
        return (
            <div>
            <h1>SignUp</h1>
            </div>
        );
    }
}

export default SignUp;