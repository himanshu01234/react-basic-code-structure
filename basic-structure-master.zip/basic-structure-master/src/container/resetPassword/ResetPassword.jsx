import React, {Component} from 'react';

class ResetPassword extends Component {
    render() {
        return (
            <div>
                <h1>ResetPassword</h1>
            </div>
        );
    }
}

export default ResetPassword;