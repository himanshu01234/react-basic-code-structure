import React, {Component} from 'react';

class ForgotPassword extends Component {
    render() {
        return (
            <div>
                <h1>ForgotPassword</h1>
            </div>
        );
    }
}

export default ForgotPassword;