import React from 'react';
// import Dashboard from "./Dashboard/Dashboard";
// import EditRegisteredUser from "../Admin/EditRegisteredUser";


class User extends React.Component{
    render(){
        return(
            <div  className="text-center">
                <h1>You are user, you can't update users</h1>
                {/*<EditRegisteredUser/>*/}


                {/*<Dashboard/>*/}

            </div>
        );
    }
}

export default User;