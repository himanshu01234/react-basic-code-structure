const routesRule = {

    home: '/home',
    about: '/about',
    user: '/user',
};

export default routesRule;